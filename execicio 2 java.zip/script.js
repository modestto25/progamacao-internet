let somar = document.querySelector("#somar");
let somar2 = document.querySelector("#somar2");
let btresultado= document.querySelector("#btresultado");
let resultado= document.querySelector("#resultado");

function resultadovalor(){

    let num1 = Number (somar.value)
    let num2 = Number (somar2.value)

    resultado.textContent = (num1 * num2);
}

btresultado.onclick = function (){
    
    resultadovalor();

}